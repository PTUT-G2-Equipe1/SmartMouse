
import java.util.*;

/**
 * <b>écran tactile est la classe représentant l'écran du téléphone.</b>
 */
public class Ecran_Tactile {

    /**
     * Constructeur par défaut
     */
    public Ecran_Tactile() {
    }


    /**
     * Fait un setOnAction sur le bouton permettant d'accéder à la téléommande.
     */
    public void appuyerBoutonTelecommande() {

    }



    /**
     *Effectue l'action.
     */
    public void effectuerAction() {

    }


    /**
     * Permet à l'utilisateur de saisir manuellement quelque chose et le sauvegarde
     */
    public void saisieTactile() {

    }


    /**
     *Effectue l'action faite sur écran et la transmet au périphérique.
     */
    public void effectuerActionSurEcranPourPeriph(){

    }
}